document.addEventListener('DOMContentLoaded', function() {
    // The form submission is now handled by Formspree.
    // You can add other interactive scripts here if needed.
    
}); 